module.exports = {
    packages: {
      'ng5-slider': {
        ignorableDeepImportMatchers: [
          /ng5-slider\//,
        ]
      }
    },
  };