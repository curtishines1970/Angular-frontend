import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-left-sidebar',
  templateUrl: './blog-left-sidebar.component.html',
  styleUrls: ['./blog-left-sidebar.component.scss']
})
export class BlogLeftSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
