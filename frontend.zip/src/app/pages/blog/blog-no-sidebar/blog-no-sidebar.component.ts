import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-no-sidebar',
  templateUrl: './blog-no-sidebar.component.html',
  styleUrls: ['./blog-no-sidebar.component.scss']
})
export class BlogNoSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
