import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-one',
  templateUrl: './compare-one.component.html',
  styleUrls: ['./compare-one.component.scss']
})
export class CompareOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
